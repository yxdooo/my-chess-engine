import * as fs from 'fs/promises';

const imports = {
    './engine_wasm_bg.js': {
        __wbindgen_throw: function(msg) { console.error('WASM THROW:', msg); },
        __wbindgen_number_new: function(f) { return f; },
        __wbindgen_string_new: function(p, l) { return ""; },
        __wbg_now_86c0d4ba3fa605b8: function() { return Date.now(); }
    }
};

(async () => {
    try {
        const wasmBuffer = await fs.readFile('engine_wasm_bg.wasm');
        const module = await WebAssembly.instantiate(wasmBuffer, imports);
        const exports = module.instance.exports;
        
        console.log('WASM instantiated successfully!');
        
        const ptr = exports.chessengine_new();
        console.log('Engine created at ptr:', ptr);
        
        // Let's allocate strings for get_best_move
        const fen = "rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq -";
        
        console.log('Ready to search');
    } catch (e) {
        console.error('Error:', e);
    }
})();
